step =input("Funzione che stampa grafici di X, sqrtX, e x^2\n\nScegli la precisione (numero con la virgola tra 0 e 1):");
graficoXSqrtSq(step);
%Chiudi il programma
return;